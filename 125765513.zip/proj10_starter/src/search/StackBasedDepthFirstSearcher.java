package search;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Stack;

/**
 * An implementation of a Searcher that performs an iterative search,
 * storing the list of next states in a Stack. This results in a
 * depth-first search.
 * 
 */
public class StackBasedDepthFirstSearcher<T> extends Searcher<T> {

	public StackBasedDepthFirstSearcher(SearchProblem<T> searchProblem){
		super(searchProblem);
	}

	@Override
	public List<T> solve(){

		Stack<T> states = new Stack<T>();
		List<T> predec = new ArrayList<>();

		T initial = searchProblem.getInitialState();

		states.push(initial);
		predec.add(initial);

		List<T> answer = new ArrayList<>();

		while(!states.isEmpty()){
			T curr = states.pop();
			for(T nxt : searchProblem.getSuccessors(curr)){
				if (!predec.contains(nxt)) {
					predec.add(nxt);
					states.push(nxt);
				}
			}
			if (searchProblem.isGoalState(curr) == true){
				T previous = predec.get(predec.indexOf(curr));
				answer.add(curr);
				while (previous != null){
					answer.add(previous);
					previous = predec.get(predec.indexOf(previous));
				  }
				  break;
				}
			}
			return answer;
		}
	}
