package search;

import java.util.List;
import java.util.ArrayList;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Collections;


/**
 * An implementation of a Searcher that performs an iterative search,
 * storing the list of next states in a Queue. This results in a
 * breadth-first search.
 * 
 */
public class QueueBasedBreadthFirstSearcher<T> extends Searcher<T> {

	public QueueBasedBreadthFirstSearcher(SearchProblem<T> searchProblem){
		super(searchProblem);
	}

	@Override
	public List<T> solve() {
		Queue<T> states = new LinkedList<>();
		List<T> predec = new ArrayList<>();
		T initial = searchProblem.getInitialState();

		states.add(initial);
		predec.add(initial);

		List<T> answer = new ArrayList<>();

		while(!states.isEmpty()){
			T curr = states.remove();
			for (T nxt : searchProblem.getSuccessors(curr)){
				if (!predec.contains(nxt)){
					states.add(nxt);
					predec.add(nxt);
				  }
				}
			if(searchProblem.isGoalState(curr) == true){
				T previous = predec.get(predec.indexOf(curr));
				answer.add(curr);
				while( previous != null){
					answer.add(previous);
					previous = predec.get(predec.indexOf(previous));
				}
				break;
			}
		}
		return answer;
	}
}
